######环境依赖
`java v"15.0.2"+
Eclipse 2020-12 (4.18.0)`

######部署步骤及目录结构描述

1. 创建文件夹`A`，文件夹地址为`path`
2. 在文件夹`A`中创建`Eclipse`工作区域
4. 在2中创建的工作区域内导入项目文件夹`RPG_Factory`
6. 运行`main.java`开始游戏

```json
A
├── RPG_Factory
│  ├── Maps
│  │  ├── Pictures
│  │  │  ├── 001Sea.png//目前图片是乱找的，规划是001为默认海平面，002-004为海的临岸浪花图片
│  │  │  ├── 002RedTree.png
│  │  │  ├── 003GreenTree.png
│  │  │  ├── 004Bamboo.png
│  │  │  └── 005Grass.png//005是陆地默认图片，006-008是陆地边缘图片，0xx包含矿山等自然地形的贴图//1xx开始是树木、矿石等自然作
│  │  │                  //物或者是产物等贴图//2xx是人为建筑物贴图，可能会很多//4xx开始是物流运输贴图，包括道路等因素
│  │  │                  //map第一层是不会对角色产生影响，第二层是会对角色产生碰撞，第三层是能进行与玩家交互对话的
│  │  ├── map1.map
│  │  └── map2.map
│  ├── Players
│  │  └── Pictures
│  │    └── walk.png
│  └── Readme.md
└── workplace
  ├── RPG_Factory
  │  ├── bin
  │  └── src
  │    ├── GameWindow
  │    │  ├── GameConfig.java
  │    │  ├── Player.java
  │    │  ├── UpdateThread.java
  │    │  ├── main.java
  │    │  └── mainFrame.java
  │    └── Maps
  │      ├── AutoMap.java
  │      ├── MapConfig.java
  │      ├── ReadMap.java
  │      └── SetMap.java
```



###### 添加新建筑步骤

1. 寻找贴图，并正确命名
2. 修改`id.csv`和`tree.csv`按照相应格式构建输入输出，id编号
3. 将贴图加入`GameConfig`的`ImageIcon`数组
4. 确定建筑的位置（海面、陆地、树、岩石）添加进`RestoreBlocks`的集合当中
5. 添加建造按钮监听调用建造函数
6. 如有特殊功能（储存、传输等）则特殊处理

###### V0.0.0 @author gongzhili

+ 起始版本，前期工作
+ 自定义地图、自动生成地图、地图读取及主要界面显示
+ 角色移动飞行、物体边缘碰撞检测
+ 简易贴图变换

######V0.1.0 @author TEAM

+ 实现了伐木场、道路、仓库、住房、农田等建筑的建造、拆除、激活、暂停、复制、粘贴主要执行函数的封装与调试。目前还存在不少BUG，后续版本再予以调整
+ 完成了道路多向化设计，实现道路图标的实时更新
+ 实现仓库离线记录并储存功能，设置背包以记录玩家资源
+ 实现住房设计并产生全局人口，在满足条件的情况下可以产生新人口