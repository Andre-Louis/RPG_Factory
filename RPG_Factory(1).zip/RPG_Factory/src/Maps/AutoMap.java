package Maps;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

class Node {
	int x, y;

	Node(int x, int y) {
		this.x = x;
		this.y = y;
	}
}

public class AutoMap implements MapConfig {
	static int[][] map1 = new int[isize][jsize];
	static int[][] map2 = new int[isize][jsize];
	static int[][] map3 = new int[isize][jsize];
	static int land_s = (int) (isize * jsize / 2.5);
	static int[][] directions = { { 0, 1 }, { 0, -1 }, { 1, 0 }, { -1, 0 } };

	static double increase = 1.2;
	public static ConcurrentLinkedQueue<Node> lands = new ConcurrentLinkedQueue<>();

	public static void main(String[] args) {
		init();
		AutoCreate(500);
		for (int i = 0; i < 3; i++)
			AutoCreate(500);
		for (int i = 0; i < isize; i++)
			for (int j = 0; j < jsize; j++) {
				if (map1[i][j] == 1) {
					int pd = 0;
					for (int[] d : directions) {
						int x = Mod(i + d[0], isize);
						int y = Mod(j + d[1], jsize);
						if (map1[x][y] == 5)
							pd += 1;
					}
					if (pd == 4)
						map1[i][j] = 5;
				}
			}
		AutoCreateTrees();
		save();
	}

	public static void AutoCreateTrees() {
		for (int i = 0; i < isize; i++)
			for (int j = 0; j < jsize; j++) {
				if (map1[i][j] == 5) {
					double rate = Math.random();
					if(rate<0.2)
						map2[i][j]=10;
				}
			}
		
	}

	public static void init() {
		for (int[] js : map1)
			for (int j = 0; j < js.length; j++)
				js[j] = 1;
		map1[0][0] = 5;
		lands.add(new Node(0, 0));
	}

	public static void AutoCreate(int land) {

		int cnt = 0;
		while (cnt < land) {
			while (!lands.isEmpty() && cnt < land) {
				Node n = lands.poll();
				for (int[] d : directions) {
					int x = Mod(n.x + d[0], isize);
					int y = Mod(n.y + d[1], jsize);
					if (map1[x][y] == 5)
						continue;
					double rate = (land_s) / (double) (isize * jsize);

					if (map1[Mod(x - 1, isize)][y] == 5)
						rate *= increase;
					if (map1[Mod(x + 1, isize)][y] == 5)
						rate *= increase;
					if (map1[x][Mod(y - 1, jsize)] == 5)
						rate *= increase;
					if (map1[x][Mod(y + 1, jsize)] == 5)
						rate *= increase;
					rate = Math.min(rate, 1);

					double r = Math.random();
					if (r < rate) {

						map1[x][y] = 5;
						lands.add(new Node(x, y));
						cnt += 1;
					}
				}
			}

			while (lands.isEmpty()) {

				int x = (int) (Math.random() * isize);
				int y = (int) (Math.random() * jsize);
				if (map1[x][y] != 5) {
					map1[x][y] = 5;
					cnt += 1;
					lands.add(new Node(x, y));
				}
			}
			System.out.println(cnt + "/" + land);

		}
		lands.clear();

	}

	public static int Mod(int x, int y) {
		if (x < 0)
			return x + y;
		return x % y;
	}

	public static void save() {
		try {
			System.out.println("开始保存");
			FileOutputStream fos = new FileOutputStream("material/Maps/map2.map");
			DataOutputStream dos = new DataOutputStream(fos);
			int i = MapHeight / eleHeight;
			int j = MapWidth / eleWidth;
			// 先数组的大小写入文件
			dos.writeInt(i);
			dos.writeInt(j);
			// 按顺序将三个二维数组写入文件，记住这里的写入方式，后面游戏读取地图的时候也要按这种顺序读回来
			for (int ii = 0; ii < i; ii++) {
				for (int jj = 0; jj < j; jj++) {
					if (map1[ii][jj] == 1)
						map2[ii][jj] = 1;
					dos.writeInt(map1[ii][jj]);
					dos.writeInt(map2[ii][jj]);
					dos.writeInt(map3[ii][jj]);
				}
			}
			// 强制流中的数据完全输出完
			dos.flush();
			// 关闭输出流
			dos.close();
			System.out.println("保存完成");

		} catch (Exception ef) {
			ef.printStackTrace();
		}
	}

}
