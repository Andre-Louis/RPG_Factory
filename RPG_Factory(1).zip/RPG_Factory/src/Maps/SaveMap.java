package Maps;

import java.io.DataOutputStream;
import java.io.FileOutputStream;

import GameWindow.StartPanel;

public class SaveMap implements MapConfig{
	public static void Save()
	{
		try {
			System.out.println("开始保存");
			// 得到文件输出流
			FileOutputStream fos = new FileOutputStream(StartPanel.path + StartPanel.name +"/map.map");
			// 将文件输出流包装成基本数据输出流
			DataOutputStream dos = new DataOutputStream(fos);
			// 从配置的接口中得到二维数组的大小(由于本类已经实现了上面的Mapconfig接口，所以可以直接用里面的数据)
			int i = MapHeight / eleHeight;
			int j = MapWidth / eleWidth;
			// 先数组的大小写入文件
			dos.writeInt(i);
			dos.writeInt(j);
			// 按顺序将三个二维数组写入文件，记住这里的写入方式，后面游戏读取地图的时候也要按这种顺序读回来
			for (int ii = 0; ii < i; ii++) {
				for (int jj = 0; jj < j; jj++) {
					if (ReadMap.map1[ii][jj] == 1&&ReadMap.map2[ii][jj] == 0)
						ReadMap.map2[ii][jj] = 1;
					dos.writeInt(ReadMap.map1[ii][jj]);
					dos.writeInt(ReadMap.map2[ii][jj]);
					dos.writeInt(ReadMap.map3[ii][jj]);
				}
			}
			// 强制流中的数据完全输出完
			dos.flush();
			// 关闭输出流
			dos.close();
			System.out.println("保存完成");

		} catch (Exception ef) {
			ef.printStackTrace();
		}
	}
}
