package Maps;

import javax.swing.ImageIcon;

/**
 * 地图创建配置，所有图片编号以及素材
 * 
 * @author gongzhili
 *
 */
public interface MapConfig {
	// 素材的大小
	int eleWidth = 20;
	int eleHeight = 20;
	// 地图的大小
	int MapWidth = 4000;
	int MapHeight = 4000;

	int isize = MapWidth / eleWidth;
	int jsize = MapHeight / eleHeight;
	// 地图保存的位置
	String path = "material/Maps";
	String pic_path = path + "/Pictures/";
	// 用到的图片素材
	ImageIcon icon001 = new ImageIcon(pic_path + "001Sea.png");
	ImageIcon icon002 = new ImageIcon(pic_path + "002RedTree.png");
	ImageIcon icon003 = new ImageIcon(pic_path + "003GreenTree.png");
	ImageIcon icon004 = new ImageIcon(pic_path + "004Bamboo.png");
	ImageIcon icon005 = new ImageIcon(pic_path + "005Grass.png");
	// 将所有的图片素材对象放入一个数组中，便于窗体上的下拉列表添加所有的图片素材
	ImageIcon[] allicons = { icon001, icon002, icon003, icon004, icon005 };
}
                                                                                                    