package GameWindow;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;


public class StartPanel extends JPanel implements GameConfig{
	public static String path = "material/Archive/Saving";
	public static String name = "1";
	JComboBox<String> Savings;
	public StartPanel()
	{
		init();
	}
	public void init(){
		this.setBounds(18, 5, 650, 650);
		this.setLayout(null);
		this.setBackground(Color.black);

		this.add(setButton("开始新游戏", 300, 220, 80, 40));
		this.add(setButton("继续游戏", 300, 280, 80, 40));
		this.add(setButton("退出游戏", 300, 340, 80, 40));
		String[] names = {"1","2","3","4"};
		Savings = new JComboBox<String>(names);
		Savings.setBounds(300, 400, 80, 40);Savings.setForeground(Color.BLACK);
		this.add(Savings);
	}
	
	/**
	 * setButton - 返回一个JButton，给定坐标和宽高
	 * 
	 */
	public JButton setButton(String s, int x, int y, int width, int height) {
		JButton b = new JButton(s);
		b.setBounds(x, y, width, height);
		b.addActionListener(e -> {
			if (s.equals("继续游戏")) {
				name=(String) this.Savings.getSelectedItem();
				//System.out.println("Saving"+name);
				main.mf=new mainFrame();
				main.mf.init();
				return;}
			if (s.equals("退出游戏")) {
				main.mf=new mainFrame();
				main.mf.init();
				System.exit(0);}

		});
		return b;
	}
	@Override
	public void paint(Graphics g) {
		super.paint(g);
	}
}
