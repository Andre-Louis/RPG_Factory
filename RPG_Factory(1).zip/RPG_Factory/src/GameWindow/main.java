package GameWindow;

import Maps.ReadMap;
import Blocks.*;
public class main {
	static mainFrame mf;
	public static void main(String[] args) {
		
		// 用读到的地图数组创建游戏窗体，开始游戏
		mf = new mainFrame();
		mf.start();
		//NPCListener m=new NPCListener(mf);
		
	}
}