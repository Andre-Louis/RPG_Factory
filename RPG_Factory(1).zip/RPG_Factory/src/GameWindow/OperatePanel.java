package GameWindow;


import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Blocks.Block;
import Blocks.BlockOperator;
import Maps.ReadMap;

/**
 * 对话框面板
 * 
 * @author
 * 
 * 
 *         说明： 这个panel存在六个按钮。建造、拆除；激活、停止；复制、黏贴共六个选项
 *         其中，点击建造之后会有茅草房、伐木场、仓库、农田、道路，共五个选项，会进入到BuildingPanel里
 * 
 */
public class OperatePanel extends JPanel implements GameConfig {

	public final static int IS_AVAILABLE = 0;
	public final static int IS_TREE = 1;
	public final static int IS_BUILDING = 2;
	public final static int IS_SEA = 3;
	public final static int NOT_AVAILABLE = 4;// 4个状态

	public static int status;

	static ImageIcon Operate = new ImageIcon("material/OperatorBox/Operator.png");

	public OperatePanel() {
		init();
	}

	public void init() {
		this.setBounds(18, 5, 650, 650);
		this.setLayout(null);
		this.setBackground(Color.black);
		// this.setOpaque(false);//设置面板透明

		this.add(setButton("返回", panelX - 90, panelY - 50, 80, 40));
		// bad smell的参数设定。先这样吧。
		this.add(setButton("建造", 100, 120, 80, 40));
		this.add(setButton("拆除", panelX - 180, 120, 80, 40));
		this.add(setButton("激活", 100, 280, 80, 40));
		this.add(setButton("停止", panelX - 180, 280, 80, 40));
		this.add(setButton("复制", 100, 440, 80, 40));
		this.add(setButton("黏贴", panelX - 180, 440, 80, 40));

	}

	/**
	 * setButton - 返回一个JButton，给定坐标和宽高
	 * 
	 */
	public JButton setButton(String s, int x, int y, int width, int height) {
		JButton b = new JButton(s);
		b.setBounds(x, y, width, height);
		/**
		 * 下面是按钮的响应函数。 加入了错误信息警告
		 * 
		 */
		b.addActionListener(e -> {
			status = icon_status();
			if (s.equals("建造")) {
				if (status == IS_AVAILABLE || status == IS_TREE) {
					mainFrame.state = 2;
					mainFrame.layout.next(mainFrame.panels);
				} else
					error_msg("不能在非空地上建造");
				return;
			} else if (s.equals("拆除")) {
				if (status == IS_BUILDING) {
					BlockOperator.Delete(mainFrame.Setx, mainFrame.Sety);
				} else
					error_msg("此处无建筑");
			} else if (s.equals("激活")) {
				if (status == IS_BUILDING) {
					BlockOperator.Start(mainFrame.Setx, mainFrame.Sety);
				} else
					error_msg("此处无建筑");
			} else if (s.equals("停止")) {
				if (status == IS_BUILDING) {
					BlockOperator.Pause(mainFrame.Setx, mainFrame.Sety);
				}
			} else if (s.equals("复制")) {
				if (status == IS_BUILDING) {
					Block block = Block.getMap()[mainFrame.Setx][mainFrame.Sety];
					if (block != null)
						mainFrame.savedBuildingNumber = block.id;
					else {
						error_msg("此处无建筑");
					}

				}
			} else if (s.equals("黏贴")) {
				if (status == IS_AVAILABLE) {
					BlockOperator.Build(mainFrame.Setx, mainFrame.Sety, mainFrame.savedBuildingNumber);
				} else
					error_msg("不能在非空地上黏贴");
			}
			// 完成功能之后返回。返回按钮只完成这三个语句
			mainFrame.state = 0;
			mainFrame.layout.previous(mainFrame.panels);
			// System.out.println(mainFrame.state+" return!");

		});
		return b;
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
	}

	/**
	 * error_msg - 对非法操作进行警告，弹出窗口 静态函数，被BuildingPanel和BlockOperator调用
	 */
	public static void error_msg(String str) {
		JOptionPane.showMessageDialog(null, str, "错误！", JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * icon_status - 返回该icon的状态值
	 *
	 */
	public int icon_status() {
		int ss = ReadMap.map2[mainFrame.Sety][mainFrame.Setx];
		int ss1 = ReadMap.map1[mainFrame.Sety][mainFrame.Setx];

		// System.out.println("status "+ss);
		if (ss == 10)// 是树
			return IS_TREE;
		if (ss == 1)// 是海
			return IS_SEA;
		if (ss >= 200 || ss1 >= 400)// 是人为建筑或者物流
			return IS_BUILDING;
		return IS_AVAILABLE;
	}

	public static int Mod(int x, int y) {
		if (x < 0)
			return x + y;
		return x % y;
	}
}
