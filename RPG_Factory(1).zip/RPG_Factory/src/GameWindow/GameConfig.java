package GameWindow;

import javax.swing.ImageIcon;

public interface GameConfig {
	int MapWidth = 4000;
	int MapHeight = 4000;
	// 游戏主窗体名字
	String title = "场景移动小游戏";
	// 游戏主窗体的大小
	int frameX = 700;
	int frameY = 700;
	// 游戏面板大小
	int panelX = 650;
	int panelY = 650;
	// 游戏素材大小
	int elesize = 20;
	// 人物大小
	int playersize = 20;
	// 游戏素材保存位置
	
	String path = "material/Maps";
	String pic_path = path + "/Pictures/";
	// ------------[游戏素材]----------
	// -----第一层
	ImageIcon icon001 = new ImageIcon(pic_path + "001Sea.png");

	ImageIcon icon010 = new ImageIcon(pic_path + "010GreenTree.png");

	ImageIcon icon005 = new ImageIcon(pic_path + "005Grass.png");

	ImageIcon icon201 = new ImageIcon(pic_path + "201LumberYard.png");
	ImageIcon icon202 = new ImageIcon(pic_path + "202LumberYard_Work.png");
	ImageIcon icon203 = new ImageIcon(pic_path + "203Farmland.png");
	ImageIcon icon204 = new ImageIcon(pic_path + "204Farmland_Work.png");
	ImageIcon icon205 = new ImageIcon(pic_path + "205Cottage.png");
	ImageIcon icon206 = new ImageIcon(pic_path + "206Cottage_Work.png");
	
	ImageIcon icon401 = new ImageIcon(pic_path + "401Road.png");
	ImageIcon icon402 = new ImageIcon(pic_path + "402Road.png");
	ImageIcon icon403 = new ImageIcon(pic_path + "403Road.png");
	ImageIcon icon404 = new ImageIcon(pic_path + "404Road.png");
	ImageIcon icon405 = new ImageIcon(pic_path + "405Road.png");
	ImageIcon icon406 = new ImageIcon(pic_path + "406Road.png");
	ImageIcon icon407 = new ImageIcon(pic_path + "407Road.png");
	ImageIcon icon408 = new ImageIcon(pic_path + "408Road.png");
	ImageIcon icon409 = new ImageIcon(pic_path + "409Road.png");
	ImageIcon icon410 = new ImageIcon(pic_path + "410Road.png");
	ImageIcon icon411 = new ImageIcon(pic_path + "411Road.png");
	ImageIcon icon412 = new ImageIcon(pic_path + "412Road.png");
	ImageIcon icon413 = new ImageIcon(pic_path + "413Road.png");
	ImageIcon icon414 = new ImageIcon(pic_path + "414Road.png");
	ImageIcon icon415 = new ImageIcon(pic_path + "415Road.png");
	ImageIcon icon416 = new ImageIcon(pic_path + "416Road.png");
	
	ImageIcon icon501 = new ImageIcon(pic_path + "501Warehouse.png");
	ImageIcon icon502 = new ImageIcon(pic_path + "502Warehouse_Work.png");
	
	ImageIcon marquee = new ImageIcon("material/Players/Pictures/marquee.png");
	// 镜头

	// ImageIcon shadow2 = new ImageIcon("镜头阴影2.png");

	// 利用数字得到图像
	ImageIcon[] allicons = { icon001, icon005, icon010, 
			icon201, icon202, icon203, icon204, icon205, icon206, 
			icon401, icon402, icon403, icon404, icon405, icon406, icon407, icon408, icon409, icon410, icon411, icon412, icon413, icon414, icon415, icon416
			, 
			icon501, icon502};

}
