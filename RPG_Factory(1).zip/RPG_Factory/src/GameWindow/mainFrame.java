package GameWindow;


import java.awt.*;
import java.awt.event.*;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.*;

import Blocks.Bag;
import Blocks.BlockOperator;
import Blocks.RestoreBlocks;
import Course.Mydialog;
import Course.NPCListener;
import Maps.*;

public class mainFrame extends JFrame implements GameConfig {
	// 游戏、操作面板
	static JPanel panel;
	static JPanel Opanel;
	static JPanel Bpanel;
	static JPanel panels;
	public static JLabel bag;
	static CardLayout layout = new CardLayout();

	static int Mousex,Mousey;
	//建造的位置
	static int Setx, Sety;
	static ConcurrentHashMap<Integer, ImageIcon> map = new ConcurrentHashMap<Integer, ImageIcon>();
	//面板状态 0 游戏界面 1 操作界面 2 建造界面
	static int state=0;
	//复制的建筑的编号
	static int savedBuildingNumber = 0;
	public mainFrame() {
		//init();
		//start();
	}
	/**
	 * 开始界面
	 */
	public void start()
	{
		this.setTitle(title);
		this.setSize(frameX, frameY);
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(3);
		
		JPanel start = new StartPanel();
		this.add(start,BorderLayout.CENTER);

		this.setVisible(true);
	}
	/**
	 * 设置窗体
	 */
	public void init() {
		//初始化建筑操作系统
		BlockOperator.init();
		// 首先从地图文件中读入地图数组
		ReadMap.readfile(StartPanel.path + StartPanel.name +"/map.map");			
		RestoreBlocks.ReadXML();
		Bag.ReadGlobal();
		
		this.setTitle(title);
		this.setSize(frameX, frameY);
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(3);
		// 创建游戏面板
		for (ImageIcon allicon : allicons) {
			int num = str2int(allicon.toString().substring(pic_path.length(), pic_path.length() + 3));
			map.put(num, allicon);
		}

		panels = new JPanel(layout);
		panel = setpanel();
		Opanel = setOpanel();
		Bpanel = setBpanel();
	
		//test = new JLabel();
		//Mousetest = new JLabel();
		panels.add(panel);
		panels.add(Opanel);
		panels.add(Bpanel);
		this.add(panels,BorderLayout.CENTER);
		bag = new JLabel("start");
		//bag.setBounds(650,650,40,20);
		this.add(bag,BorderLayout.EAST);
		
		JButton Save = new JButton("Save");
		Save.addActionListener(e -> {
			Maps.SaveMap.Save();
			Blocks.SaveBlocks.Save();
			Blocks.Bag.SaveGlobal();
		});
		this.add(Save,BorderLayout.SOUTH);
		//this.add(test);
		//this.add(Mousetest);
		this.setVisible(true);
		// 安装监听器
		PanelListenner plis = new PanelListenner();
		PanelMouseListenner mlis = new PanelMouseListenner();
		this.addKeyListener(plis);
		this.setFocusable(true);
		panel.addMouseMotionListener(mlis);
		panel.addMouseListener(mlis);
		
		//NPCListener.npc_init();
		// 启动人物移动线程
		Player player = new Player();
		player.start();

		// 启动刷新面板线程
		UpdateThread ut = new UpdateThread(panel,Opanel,Bpanel,bag);
		ut.start();
	}

	/**
	 * 设置游戏面板
	 */
	public JPanel setpanel() {
		JPanel panel = new MyPanel();
		panel.setPreferredSize(new Dimension(panelX, panelY));
		panel.setLayout(null);
		panel.setBackground(Color.black);
		return panel;
	}
	/** 
     * 设置操作面板 
     * @return 
     */  
    public JPanel setOpanel(){  
        JPanel Opanel = new OperatePanel();  
        return Opanel;  
    }
    /** 
     * 设置操作面板的建造面板 
     * @return 
     */ 
    public JPanel setBpanel(){  
        JPanel Bpanel = new BuildingPanel();  
        return Bpanel;  
    }
   // 解析图片名字
	public int str2int(String numstr) {
		for (int i = 0; i < 3; i++) {
			if (numstr.charAt(i) != 0) {
				numstr = numstr.substring(i);
				int num = Integer.parseInt(numstr);
				return num;
			}
		}
		numstr = numstr.substring(2);
		int num = Integer.parseInt(numstr);
		return num;
	}

	/**
	 * 内部游戏按键监听类
	 * 
	 * @author gzl
	 * 
	 */
	class PanelListenner extends KeyAdapter {
		// 当按键按下
		public void keyPressed(KeyEvent e) {
			if(state!=0)return;
			int code = e.getKeyCode();
			switch (code) {
			case KeyEvent.VK_UP:
				Player.up = true;
				break;
			case KeyEvent.VK_DOWN:
				Player.down = true;
				break;
			case KeyEvent.VK_LEFT:
				Player.left = true;
				break;
			case KeyEvent.VK_RIGHT:
				Player.right = true;
				break;
			case KeyEvent.VK_T:
				if(NPCListener.getstate()){
	                   Mydialog d=new Mydialog(main.mf);
	                   System.out.print("，Ctrl键被按下");
	               }
			default:
				break;
			}
		}

		// 当按键释放
		public void keyReleased(KeyEvent e) {
			if(state!=0)return;
			int code = e.getKeyCode();
			switch (code) {
			case KeyEvent.VK_UP:
				Player.up = false;
				break;
			case KeyEvent.VK_DOWN:
				Player.down = false;
				break;
			case KeyEvent.VK_LEFT:
				Player.left = false;
				break;
			case KeyEvent.VK_RIGHT:
				Player.right = false;
				break;

			default:
				break;
			}
		}
	}
	/**
	 * 内部游戏鼠标监听类
	 * 
	 * @author gzl
	 * 
	 */
	class PanelMouseListenner extends MouseAdapter {
		@Override
		public void mouseMoved(MouseEvent e)
		{
			if(state!=0)
				return;
			int tx=Player.x+e.getX()-Player.px;
			int ty=Player.y+e.getY()-Player.py;
			if(tx<0)tx-=elesize;
			Mousex=tx/elesize;
			if(ty<0)ty-=elesize;
			Mousey=ty/elesize;
			//Mousetest.setText(Player.Mod(Mousex, MapWidth/elesize)+","+Player.Mod(Mousey, MapHeight/elesize));
		}
		@Override
        public void mousePressed(MouseEvent e) {
          // TODO Auto-generated method stub
        }
        @Override
        public void mouseClicked(MouseEvent e) {
          // TODO Auto-generated method stub
        	if(state!=0)
        		return;
        	//System.out.println("Clicked!");
        	state=1;
        	Setx=Player.Mod(Mousex,MapWidth/elesize);
        	Sety=Player.Mod(Mousey,MapHeight/elesize);
        	//System.out.println(mainFrame.Setx+","+mainFrame.Sety);
            layout.next(panels);
        }
        @Override
        public void mouseReleased(MouseEvent e) {
          // TODO Auto-generated method stub
 
        }
        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
        }
        @Override
        public void mouseExited(MouseEvent e) {
          // TODO Auto-generated method stub
        }
		
	}
	
	/**
	 * 自定义内部游戏面板类
	 * 
	 * @author gzl
	 * 
	 */
	class MyPanel extends JPanel {
		@Override
		public void paint(Graphics g) {
			super.paint(g);

			for (int i = Player.getI() - 18; i <= Player.getI() + 18; i++) {
				for (int j = Player.getJ() - 18; j <= Player.getJ() + 18; j++) {
					int irange = ReadMap.map1.length;
					int jrange = ReadMap.map1[0].length;
					int ii = i, jj = j;
					if (i < 0)
						ii += irange;
					if (j < 0)
						jj += jrange;
					if (i >= irange)
						ii -= irange;
					if (j >= jrange)
						jj -= jrange;
					// 画第一层元素
					ImageIcon icon = map.get(ReadMap.map1[ii][jj]);
					g.drawImage(icon.getImage(),
							(Player.px - elesize / 2) + ((j - Player.getJ()) * elesize) - (Player.mx % elesize),
							(Player.py - elesize / 2) + ((i - Player.getI()) * elesize) - (Player.my % elesize),
							elesize, elesize, null);
					// 第二层
					ImageIcon icon2 = map.get(ReadMap.map2[ii][jj]);
					if (icon2 != null)
						g.drawImage(icon2.getImage(),
								(Player.px - elesize / 2) + ((j - Player.getJ()) * elesize) - (Player.mx % elesize),
								(Player.py - elesize / 2) + ((i - Player.getI()) * elesize) - (Player.my % elesize),
								elesize, elesize, null);
					// 第三层
					ImageIcon icon3;
					if(ii==4&&jj==0){
						String path="material/Coursepictures/";
						icon3 = new ImageIcon(path + "002.png");
					}else icon3 = map.get(ReadMap.map3[ii][jj]);
					if (icon3 != null)
						g.drawImage(icon3.getImage(),
								(Player.px - elesize / 2) + ((j - Player.getJ()) * elesize) - (Player.mx % elesize),
								(Player.py - elesize / 2) + ((i - Player.getI()) * elesize) - (Player.my % elesize),
								elesize, elesize, null);

				}
			}
			
			g.drawImage(marquee.getImage(), 
					(Player.px - elesize / 2) + ((Mousex - Player.getJ()) * elesize) - (Player.mx % elesize),
					(Player.py - elesize / 2) + ((Mousey - Player.getI()) * elesize) - (Player.my % elesize),
					elesize, elesize, null);

			Player.draw(g);
			//if(state!=0) g.drawImage(OperatePanel.Operate.getImage(), 0, 0, panelX, panelY, null);
		}
	}
}
