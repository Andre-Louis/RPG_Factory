package GameWindow;

import java.awt.Graphics;

import javax.swing.ImageIcon;

import Blocks.Block;
import Maps.ReadMap;

public class Player extends Thread implements GameConfig {
	// 角色中点相对游戏面板的位置(在游戏中是不变的)
	static int px = panelX / 2;
	static int py = panelY / 2;
	// 角色中点在整张地图中的位置(设置人最开始中点的位置一定要是一个元素中心的位置)
	static int x = elesize / 2;
	static int y = elesize / 2;
	// 角色的偏移量
	static int mx = 0;
	static int my = 0;
	// 角色的步长
	static int step = 1;
	// 角色是否移动
	static boolean up = false;
	static boolean down = false;
	static boolean left = false;
	static boolean right = false;
	// 记录角色移动量切换图片
	static int up1 = 0;
	static int down1 = 0;
	static int left1 = 0;
	static int right1 = 0;
	// up,down,left,right
	static int towards = 2;
	// walk_pic
	static ImageIcon walk = new ImageIcon("material/Players/Pictures/walk.png");
	static int picsize = 20;
	// 角色是否可以飞行
	static boolean fly = false;
	//JLabel test;

	Player() {
		super();
		//this.test = test;
	}

	@Override
	public void run() {
		while (true) {
			move();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 角色移动的方法
	 */
	public void move() {
		step = fly ? 5 : 1;
		if (up) {
			up1++;
			if (up1 >= 20)
				up1 = 0;
			if (!fly && ReadMap.map2[Mod(y - elesize, MapHeight) / elesize][x / elesize] != 0) {
				int y1 = (y / elesize - 1) * elesize + elesize / 2;
				if ((y - y1) * (y - y1) >= elesize * elesize) {
					// 改变角色在地图中的位置
					y = Mod(y - step, MapHeight);
					// 改变角色移动相对于固定元素点的偏移量
					my = Mod(my - step, MapHeight);
				}
			} else if (fly || ReadMap.map2[Mod(y - elesize, MapHeight) / elesize][x / elesize] == 0) {// 上方没物体，可以继续向上移动
				// 改变角色在地图中的位置
				y = Mod(y - step, MapHeight);
				// 改变角色移动相对于固定元素点的偏移量
				my = Mod(my - step, MapHeight);
			}
		} else if (down) {
			down1++;
			if (down1 >= 20) {
				down1 = 0;
			}
			if (!fly && ReadMap.map2[Mod(y + elesize, MapHeight) / elesize][x / elesize] != 0) {
				int y1 = (y / elesize + 1) * elesize + elesize / 2;
				if ((y - y1) * (y - y1) >= elesize * elesize) {
					// 改变角色在地图中的位置
					y = Mod(y + step, MapHeight);
					// 改变角色移动相对于固定元素点的偏移量
					my = Mod(my + step, MapHeight);
				}
			} else if (fly || ReadMap.map2[Mod(y + elesize, MapHeight) / elesize][x / elesize] == 0) {
				// 改变角色在地图中的位置
				y = Mod(y + step, MapHeight);
				// 改变角色移动相对于固定元素点的偏移量
				my = Mod(my + step, MapHeight);
			}
		}
		if (left) {
			left1++;
			if (left1 >= 20) {
				left1 = 0;
			}
			if (!fly && ReadMap.map2[y / elesize][Mod(x - elesize, MapWidth) / elesize] != 0) {
				int x1 = (x / elesize - 1) * elesize + elesize / 2;
				if ((x - x1) * (x - x1) >= elesize * elesize) {
					x = Mod(x - step, MapWidth);
					mx = Mod(mx - step, MapWidth);
				}
			} else if (fly || ReadMap.map2[y / elesize][Mod(x - elesize, MapWidth) / elesize] == 0) {
				x = Mod(x - step, MapWidth);
				mx = Mod(mx - step, MapWidth);
			}

		} else if (right) {
			right1++;
			if (right1 >= 20) {
				right1 = 0;
			}
			if (!fly && ReadMap.map2[y / elesize][Mod(x + elesize, MapWidth) / elesize] != 0) {
				int x1 = (x / elesize + 1) * elesize + elesize / 2;
				if ((x - x1) * (x - x1) >= elesize * elesize) {
					x = Mod(x + step, MapWidth);
					mx = Mod(mx + step, MapWidth);
				}
			} else if (fly || ReadMap.map2[y / elesize][Mod(x + elesize, MapWidth) / elesize] == 0) {
				x = Mod(x + step, MapWidth);
				mx = Mod(mx + step, MapWidth);
			}
		}
		//test.setText(x + "," + y + ";" + mx + "," + my + ";" + (py - elesize / 2 - my % elesize));
	}

	// 得到角色在数组中的位置I
	public static int getI() {
		return Mod((y - (playersize / 2)), MapHeight) / elesize;
	}

	// 得到角色在数组中的位置J
	public static int getJ() {
		return Mod((x - (playersize / 2)), MapWidth) / elesize;
	}

	// 绘制人物
	public static void draw(Graphics g) {
		if(ReadMap.map1[getI()][getJ()]>=500)
		{
			if(Block.getMap()[getJ()][getI()].getMode()==Block.WORK)
			{
				Block.getMap()[getJ()][getI()].refresh();}
		}
		// 如果角色不在移动中
		if (!up && !down && !left && !right) {
			if (towards == 1) {// 如果角色移动的最后朝向为上
				g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize,
						Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize * 3, picsize,
						picsize * 4, null);
			} else if (towards == 2) {// 最后移动朝向下
				g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
						Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, 0, picsize, picsize, null);
			} else if (towards == 3) {// 最后移动朝向左
				g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
						Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize, picsize, picsize * 2,
						null);
			} else if (towards == 4) {// 最后移动朝向右
				g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
						Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize * 2, picsize,
						picsize * 3, null);
			}
		} else {// 如果角色在移动中
			if (up) {
				// 通过up1的值，来决定画哪一张图片
				if (up1 < 5) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize * 3, picsize,
							picsize * 4, null);
				} else if (up1 < 10) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize, picsize * 3,
							picsize * 2, picsize * 4, null);
				} else if (up1 < 15) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 2, picsize * 3,
							picsize * 3, picsize * 4, null);
				} else {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 3, picsize * 3,
							picsize * 4, picsize * 4, null);
				}
			} else if (down) {
				if (down1 < 5) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, 0, picsize, picsize, null);
				} else if (down1 < 10) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize, 0, picsize * 2,
							picsize, null);
				} else if (down1 < 15) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 2, 0, picsize * 3,
							picsize, null);
				} else {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 3, 0, picsize * 4,
							picsize, null);
				}
			} else if (left) {
				if (left1 < 5) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize, picsize,
							picsize * 2, null);
				} else if (left1 < 10) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize, picsize, picsize * 2,
							picsize * 2, null);
				} else if (left1 < 15) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 2, picsize,
							picsize * 3, picsize * 2, null);
				} else {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 3, picsize,
							picsize * 4, picsize * 2, null);
				}

			} else if (right) {
				if (right1 < 5) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, 0, picsize * 2, picsize,
							picsize * 3, null);
				} else if (right1 < 10) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize, picsize * 2,
							picsize * 2, picsize * 3, null);
				} else if (right1 < 15) {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 2, picsize * 2,
							picsize * 3, picsize * 3, null);
				} else {
					g.drawImage(walk.getImage(), Player.px - elesize / 2 - 10, Player.py - elesize / 2 - 10,
							Player.px - elesize / 2 + 20, Player.py - elesize / 2 + 20, picsize * 3, picsize * 2,
							picsize * 4, picsize * 3, null);
				}
			}
		}
	}

	public static int Mod(int x, int y) {
		if (x < 0)
			return x + y;
		return x % y;
	}
}