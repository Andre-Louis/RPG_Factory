package GameWindow;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Blocks.Bag;

public class UpdateThread extends Thread {
	JPanel panel;
	JPanel Opanel;
	JPanel Bpanel;
	JLabel bag;
	public UpdateThread(JPanel panel, JPanel Opanel, JPanel Bpanel, JLabel bag) {
		this.panel = panel;
		this.Opanel = Opanel;
		this.Bpanel = Bpanel;
		this.bag=bag;
	}

	@Override
	public void run() {
		while (true) { 
			bag.setText(Bag.paint());;
			if(mainFrame.state==0)
				panel.repaint();
			if(mainFrame.state==1)
				Opanel.repaint();
			if(mainFrame.state==2)
				Bpanel.repaint();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}