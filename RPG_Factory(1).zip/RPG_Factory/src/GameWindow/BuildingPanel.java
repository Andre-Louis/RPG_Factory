package GameWindow;



import java.awt.Color;  
import java.awt.Graphics;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import Blocks.BlockOperator;



/**
 * 
 * @author zhengxiuqi
 * 
 * 说明：
 * 
 * 这里是第三个panel，status 值为2
 * 有茅草房、伐木场、仓库、农田、道路，共五个选项
 * 
 */

public class BuildingPanel extends JPanel implements GameConfig{  

	static String[] buildingtypes = {"茅草房","伐木场","仓库","农田","道路"};//后续直接加在这里就可以啦
	JComboBox<String> buildingList;
	
	public BuildingPanel() {  
        init();  
    }  
    
    public void init(){  
        this.setBounds(18, 5, 650, 650);  
        this.setLayout(null); 
        this.setBackground(Color.black);
        //this.setOpaque(false);//设置面板透明  
        
        buildingList = new JComboBox<String>(buildingtypes);
        buildingList.setBounds(400, 300,100, 20);
        JLabel buildingChoice = new JLabel("请选择建筑类型：");
        buildingChoice.setBounds(200, 300, 130, 20);buildingChoice.setForeground(Color.WHITE);//字体设置成白色，因为背景暂时是黑色对
        this.add(buildingChoice);
        this.add(buildingList);
        this.add(setButton("返回",panelX-90,panelY-50,80,40));
        this.add(setButton("确定",panelX-190,panelY-50,80,40));
    }  


    public JButton setButton(String s,int x,int y,int width,int height)
    {
    	JButton b = new JButton(s);
    	b.setBounds(x,y,width,height);
    	if(s.equals("返回"))
    	{
    		b.addActionListener(e -> {
    			mainFrame.state=1;
        	   	mainFrame.layout.previous(mainFrame.panels);
        	   	//System.out.println(mainFrame.state+"return!");
    		});
    	}
    	else if(s.equals("确定")) {
    		
    		b.addActionListener(e -> {
    			String str = (String)this.buildingList.getSelectedItem();
    			BlockOperator.Build(mainFrame.Setx,mainFrame.Sety,str);
        		mainFrame.state=0;
        	   	mainFrame.layout.next(mainFrame.panels);
    		});
    	}
    	return b;
    }

    @Override  
    public void paint(Graphics g) {  
        super.paint(g);  
    }  
    
}

