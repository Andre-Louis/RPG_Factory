package Course;

import javax.swing.*;
import Blocks.Bag;


public class Mydialog{
    String path="material/Coursepictures/";
    public Mydialog(JFrame owner) {
    	System.out.println("dialog");
        ImageIcon icon1 = new ImageIcon(path + "003.png");
        int ans= JOptionPane.showConfirmDialog(owner,
                "新的征程已经开始\n"
                        + "你是否准备开始探索?","新手教程",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,icon1);
        if(ans==JOptionPane.YES_OPTION)
            start(owner);
       else{
            ImageIcon icon2 = new ImageIcon(path + "003.png");
            JOptionPane.showMessageDialog(owner,
                    "真可惜！\n"+
                            "但我相信你会再来的！\n","新手教程",
                    JOptionPane.INFORMATION_MESSAGE,icon2
            );
        }
    }
    public void start(JFrame o){
        ImageIcon icon = new ImageIcon(path + "002.png");
        Object[] options = {"是！",
                "否！",
                "我已学会，现在就退出!"};
        int ans= JOptionPane.showOptionDialog(o,
                "点击地图上的树木\n"
                        + "鼠标操作收集木材\n"
                        + "是否成功？","第一阶段",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                icon,options,options[2]);
        boolean mark2=false;
        if(ans==JOptionPane.YES_OPTION){
           mark2=true;
        }else if(ans==JOptionPane.NO_OPTION){
            //调用教学函数
                mark2=true;
             }
        if(mark2){
            int ans2= JOptionPane.showOptionDialog(o,
                    "点击地图上的平原\n"
                            + "收集谷物\n"
                            + "是否收集成功?","第二阶段",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    icon,options,options[2]);
            boolean mark3=false;
            if(ans2==JOptionPane.YES_OPTION){
                mark3=true;
            }else if(ans2==JOptionPane.NO_OPTION){
                //调用教学函数
                mark3=true;
            }
            if(mark3){
                boolean mark4=false;
                int ans3= JOptionPane.showOptionDialog(o,
                        "点击平原建造类——草屋\n"
                                + "草屋可以产生人口\n"
                                + "查看是否有足够的谷物，足够就开始建造草屋\n"
                                + "不足就继续收集\n"
                                + "是否成功建造?","第四阶段",
                        JOptionPane.YES_NO_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        icon,options,options[2]);
                if(ans3==JOptionPane.YES_OPTION){
                   mark4=true;
                }else if(ans2==JOptionPane.NO_OPTION){
                    //调用教学函数
                    mark4=true;
                }
                if(mark4){
                    int ans4= JOptionPane.showOptionDialog(o,
                            "点击平原建造类--伐木场\n"
                                    +"伐木场可以加工木材\n"
                                    + "查看是否有足够的木材以及人口，如果足够就开始建造\n"
                                    + "不足就继续收集木材\n"
                                    + "是否成功建造?","第四阶段",
                            JOptionPane.YES_NO_CANCEL_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            icon,options,options[2]);
                    if(ans4==JOptionPane.YES_OPTION){
                        JOptionPane.showMessageDialog(o,
                                "恭喜你已经完成了新手训练！\n"+
                                        "现在就开始你的征途吧！\n","完结撒花！",
                                  JOptionPane.INFORMATION_MESSAGE,icon
                                );
                        Bag.add(102, 10);
                    }else{
                        //再进行一遍教程
                    }
                }
            }
        }
    }
}
