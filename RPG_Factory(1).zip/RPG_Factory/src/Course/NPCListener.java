package Course;

import GameWindow.Player;
import static java.lang.Math.abs;

public class NPCListener{
    public static int npcx = 4;
    public static int npcy = 0;
    static boolean state=false;
    /**
    public NPCListener(JFrame o){
       o.addKeyListener(new KeyListener() {
           @Override
           public void keyTyped(KeyEvent e) {
           }

           @Override
           public void keyPressed(KeyEvent e) {
               int keyCode = e.getKeyCode();
               if(keyCode==VK_T&&getstate()){
                   Mydialog d=new Mydialog(o);
                   System.out.print("，Ctrl键被按下");
               }
           }
           @Override
           public void keyReleased(KeyEvent e) {
           }
       });
    }*/
    public static boolean getstate(){
    	System.out.println("check");
        if((abs(Player.getI()-npcx)<3)&&(abs(Player.getJ()-npcy)<3))
          state=true;
        return state;
    }
    /**
	public static void npc_init() {
		//ReadMap.map3[npcx][npcy]=
		
	};*/
}
