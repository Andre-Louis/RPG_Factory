package Blocks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.concurrent.ConcurrentHashMap;

import GameWindow.StartPanel;

/**
 * 全局背包，记录玩家资源
 * @author gongzhili
 *
 */
public class Bag {
	//背包MAP，储存物品(id,num)
	static ConcurrentHashMap<Integer, Integer> map = new ConcurrentHashMap<Integer, Integer>();
	/**
	 * 向背包中添加物品
	 * @param id
	 * @param num
	 */
	public static void add(int id, int num)
	{
		if(map.get(id)==null)map.put(id, num);
		else
		{
			map.put(id, map.get(id)+num);
		}
	}
	/**
	 * 删除某物品，如果玩家数量不足则返回false，否则返回true
	 * @param id
	 * @param num
	 * @return
	 */
	public static boolean del(int id, int num)
	{
		if(id==0)return true;
		if(map.get(id)==null)return false;
		int re=map.get(id);
		if(re<num)return false;
		map.put(id, re-num);
		return true;
	}
	/**
	 * 将背包数据转换为Stirng便于玩家查看
	 * @return
	 */
	public static String paint()
	{			
		String s ="<html><body>";			
		s+="People:"+Block.People+"<br>";
		for(Integer x :map.keySet())
		{
			int xx= x.intValue();
			s+=xx;
			int y=map.get(xx);
			s+=":"+y+"<br>";
		
		}
		s+="</body></html>";
		//System.out.println(s);
		return s;
	}
	/**
	 * 将全局资源储存为Global.txt文件
	 */
	public static void SaveGlobal()
	{
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(StartPanel.path + StartPanel.name +"/Global.txt"));
			writer.write("101,"+Block.People);
			writer.newLine();
			for(Integer x :map.keySet())
			{
				int xx= x.intValue();
				int y=map.get(xx);
				writer.write(xx+","+y);
				writer.newLine();
			}
			writer.flush();
			writer.close();
			System.out.println("生成全局存档成功");
		}catch (Exception e) { 
            e.printStackTrace(); 
        } 
		
	}
	/**
	 * 读取Global.txt文件恢复全局资源
	 */
	public static void ReadGlobal()
	{
		map.clear();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(StartPanel.path + StartPanel.name +"/Global.txt"));
			Block.People=Integer.parseInt(reader.readLine().split(",")[1]);
			String line;
			while((line=reader.readLine())!=null)
			{
				String[] l=line.split(",");
				int x=Integer.parseInt(l[0]);
				int y=Integer.parseInt(l[1]);
				map.put(x, y);
			}
		}catch (Exception e) { 
            e.printStackTrace(); 
        } 
	}
}
