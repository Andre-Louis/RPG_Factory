package Blocks;

import java.util.*;

import GameWindow.GameConfig;
import Maps.MapConfig;
import Maps.ReadMap;

/**
 * 东南西北物流接口
 * 
 * @author gzl
 * 
 */
class DirectionInterface {
	// 0 暂停，1 输入，2 输出
	int state;
	// 传输物品的编号
	int id;
	// 传输物品的数目
	int num;

	public DirectionInterface() {
		init();
	}

	public void init() {
		set(0, 0, 0);
	}

	public void set(int state, int id, int num) {
		this.state = state;
		this.id = id;
		this.num = num;
	}
}

/**
 * Block基类
 * 
 * @author andrexu and gongzhili
 *
 */

public class Block implements BlockConfig {
	/*------------- static -------------*/
	/* 初始化BLOCK地图 */
	static Block[][] map = new Block[MapConfig.isize][MapConfig.jsize];
	/* 储存位置和block的信息 */
	static int People = 1;
	/*------------- public -------------*/
	/* block的类型编号，可以由别的文件导入输入输出,层数信息；block属性: 输入与输出, [id, num]的格式表示 */
	public int id;
	/* 是不是物流类 */
	public boolean isroad = false;
	/* 是不是仓库类 */
	public boolean iswarehouse = false;
	/* block的位置 */
	int x, y;
	/*------------- private -------------*/
	/* 输入输出模式，根据id可以获得 */
	int[][] input, output;
	/* 建造消耗费用 */
	int costid, costnum;
	/* block位于地图第几层 */
	int level = 1;
	/* block的物品盈余 */
	int[][] temp;
	/* 最近读取时间 */
	Date date;
	/* 东南西北物流接口 */
	int East = 0;
	int South = 1;
	int West = 2;
	int North = 3;
	DirectionInterface[] ITF = { new DirectionInterface(), new DirectionInterface(), new DirectionInterface(),
			new DirectionInterface() };
	/* 东南西北四个方向的地理坐标 */
	int[][] directions;
	/* 工作状态 */
	int mode = TERM;
	/* 5 land 10 tree 1 sea */
	int on = 0;
	/* 刷新的缓冲区 */
	int buff = 0;

	/**
	 * 根据位置初始化block，所有设置均为默认状态
	 * 
	 * @param x
	 * @param y
	 */
	public void init(int x, int y) {
		this.x = x;
		this.y = y;
		mode = REST;
		input = new int[4][2];
		output = new int[4][2];
		temp = new int[4][2];
		level = 1;
		int[][] d = { { Mod(x + 1, GameConfig.MapWidth / GameConfig.elesize), y },
				{ x, Mod(y + 1, GameConfig.MapHeight / GameConfig.elesize) },
				{ Mod(x - 1, GameConfig.MapWidth / GameConfig.elesize), y },
				{ x, Mod(y - 1, GameConfig.MapHeight / GameConfig.elesize) } };
		directions = d;
		getMap()[x][y] = this;// 设置地图位置
		date = new Date(System.currentTimeMillis());
	}

	/**
	 * 改变工作状态
	 * 
	 * @param mode
	 */
	public void changeModeTo(int mode) {
		this.mode = mode;
	}

	/**
	 * 获取工作状态
	 * 
	 * @return
	 */
	public int getMode() {
		return mode;
	}

	/**
	 * 获取全局地图
	 * 
	 * @return
	 */
	public static Block[][] getMap() {
		return map;
	}

	/**
	 * 判断是否能启动, 暂停, 拆除 能启动当且仅当block处于休息状态且输入被满足 启动工作, 如果启动不成功返回false
	 * 
	 * @return
	 */
	public boolean Start() {
		if (mode != REST) {
			System.err.println("Not a REST block");
			return false;
		}
		if (isroad == false) {
			// 记录各个方向的物流输入 0123东南西北 [id, num]
			int[][] in = new int[4][2];
			// 需要的人
			int people = 0;
			// 遍历各个要求的原料检测
			for (int i = 0; i < 4; i++) {
				// 如果没有要求的原料就跳过
				if (input[i][0] == 0)
					continue;
				// 101是人口编号
				if (input[i][0] == 101) {
					if (input[i][1] > People) {
						System.err.println("People id not enough:" + People / input[i][1]);
						return false;
					}
					people = input[i][1];
					continue;
				}
				// 如果有要求的非人口原料
				int id = input[i][0];
				int num = input[i][1];
				System.out.println("Checking " + id + "," + num);
				// 遍历上下左右方块来检测是否满足输入
				for (int k = 0; k < 4; k++) {
					if (map[directions[k][0]][directions[k][1]] == null
							|| getMap()[directions[k][0]][directions[k][1]].mode != WORK)
						continue;// 如果该方向没有工作方块
					System.out.println("Checking " + in[k][0]);
					if (in[k][0] == 0)// 如果接口没有被占用
					{
						for (int[] item : map[directions[k][0]][directions[k][1]].temp) {// 如果有对应的盈余物资则将需要的num减去并记录，注意#要保证此接口没有别的物品
							System.out.println("Checking " + item[0] + "," + item[1]);
							if (item[0] == id) {
								in[k][0] = id;
								if (num <= item[1])// 如果已经可以满足
								{
									in[k][1] = num;
									num = 0;
									break;
								} else// 否则就扣除
								{
									in[k][1] = item[1];
									num -= in[k][1];
								}
							}
						}
					}
					if (num == 0)
						break;
				}
				if (num > 0)
					return false;// 如果不能满足则返回错误
			} // 所有的原料均满足，可以启动
				// 扣除人口要求
			People -= people;
			// 扣除资源要求并设置接口状态
			for (int i = 0; i < 4; i++)// 遍历四个接口设置状态
			{
				// 扣除对应输出方块的盈余
				if (getMap()[directions[i][0]][directions[i][1]] != null) {
					for (int[] item : getMap()[directions[i][0]][directions[i][1]].temp) {
						if (item[0] == in[i][0])
							item[1] -= in[i][1];
						// 如果没有了就将其去除
						if (item[1] == 0)
							item[0] = 0;
					}
					// 设置输出方块的对应的接口
					// 0-2,1-3
					int j = (i + 2) % 4;
					if (in[i][0] > 0) {
						map[directions[i][0]][directions[i][1]].ITF[j].set(2, in[i][0], in[i][1]);
						map[directions[i][0]][directions[i][1]].refresh_image();
					}
					// 设置本方块的输入旧口
					if (in[i][0] > 0)
						this.ITF[i].set(1, in[i][0], in[i][1]);
				}
			}
			// 把输出规划到盈余产出
			for (int i = 0; i < 4; i++) {
				if (output[i][0] == 101) {
					People += output[i][1];// 特殊判断人口
				} else {
					temp[i][0] = output[i][0];
					temp[i][1] = output[i][1];
				}
			}
			changeModeTo(WORK);
			buff = 0;
			this.Printinfo();
			return true;
		} else {
			int num = 0;
			int id = 0;
			for (int i = 0; i < 4; i++)// 遍历四个接口设置状态
			{
				// System.out.println("Road is starting"+directions[i][0]+","+directions[i][1]);
				int tn = 0;
				// 扣除对应输出方块的盈余
				if (map[directions[i][0]][directions[i][1]] != null) {
					for (int[] item : getMap()[directions[i][0]][directions[i][1]].temp) {
						if (id == 0 && item[0] != 0) {
							id = item[0];
						}
						if (id == item[0]) {
							tn = item[1];
							item[1] = 0;
							item[0] = 0;
						}
					}
					// 设置输出方块的对应的接口
					// 0-2,1-3
					System.out.println("in:" + id + "," + tn);
					int j = (i + 2) % 4;
					if (tn > 0) {
						map[directions[i][0]][directions[i][1]].ITF[j].set(2, id, tn);
						map[directions[i][0]][directions[i][1]].refresh_image();
					}
					// 设置本方块的输入接口
					if (tn > 0)
						this.ITF[i].set(1, id, tn);
					num += tn;
				}
			}
			temp[0][0] = id;
			temp[0][1] = num;
			changeModeTo(WORK);
			// 刷新缓冲区与时间
			buff = 0;
			date = new Date(System.currentTimeMillis());
			this.Printinfo();
			return true;
		}
	}

	/**
	 * 暂停工作, 如果不成功返回false
	 * 
	 * @return
	 */
	public boolean pause() {
		if (this.mode != WORK)
			return false;
		for (DirectionInterface dd : ITF) {
			if (dd.state == 2)
				return false;// 如果有正在处于输出状态的接口则无法暂停
		}
		// 人口输出类
		if (this.output[0][0] == 101) {
			int num = output[0][1];
			if (People < num) {
				return false;
			} else {
				People -= num;
			}
		}
		// 如果所有接口都没有输出，意味着该block没有输出，则可以暂停
		changeModeTo(REST);// 设置停止状态
		// 返还所有的输入接口的原料
		for (int k = 0; k < 4; k++) {
			DirectionInterface dd = ITF[k];
			if (dd.state == 1)// 如果正在处于输入状态的接口
			{
				// 记录其id与num
				int id = dd.id;
				int num = dd.num;
				int l = (k + 2) % 4;
				// 重置接口
				map[directions[k][0]][directions[k][1]].ITF[l].init();
				map[directions[k][0]][directions[k][1]].refresh_image();
				// 返还资源
				for (int[] item : getMap()[directions[k][0]][directions[k][1]].temp) {
					if (item[0] == id) {
						item[1] += num;
						num = 0;
					}
				}
				if (num > 0)// 没有找到对应的条目则随便插入一条
				{
					for (int[] item : getMap()[directions[k][0]][directions[k][1]].temp) {
						if (item[0] == 0) {
							item[0] = id;
							item[1] = num;
						}
					}
				}

			}
		}
		// 停止所有接口；
		for (DirectionInterface dd : ITF) {
			dd.init();
		}
		// 重置temp
		temp = new int[4][2];
		// 返还人口
		for (int[] item : input) {
			if (item[0] == 101) {
				People += item[1];
			}
		}
		buff = 0;
		this.Printinfo();
		return true;
	}

	/**
	 * 拆除block, 不成功返回false
	 * 
	 * @return
	 */
	public boolean delete() {
		if (this.mode != REST)
			return false;
		// 检测接口状态
		for (DirectionInterface dd : ITF) {
			if (dd.state != 0) {
				System.err.println("Interface Wrong!");
				return false;
			}
		}
		// 设置虚无状态
		changeModeTo(TERM);
		return true;
	}

	/**
	 * 输出BLOCK信息
	 */
	public void Printinfo() {
		System.out.println("location:" + x + "," + y + "--------------------------");
		System.out.println("id:" + id);
		System.out.println("input:");
		for (int[] i : input) {
			System.out.println(i[0] + "," + i[1]);
		}
		System.out.println("output:");
		for (int[] i : output) {
			System.out.println(i[0] + "," + i[1]);
		}
		System.out.println("temp:");
		for (int[] i : temp) {
			System.out.println(i[0] + "," + i[1]);
		}
		System.out.println("Cost:" + costid + "," + costnum);
		// System.out.println("Creattime:"+date.toString());
		System.out.println("mode:" + mode);
		System.out.println("level:" + level);

		System.out.println("向东");
		System.out.println(ITF[0].state + ":" + ITF[0].id + "," + ITF[0].num);
		System.out.println("向南");
		System.out.println(ITF[1].state + ":" + ITF[1].id + "," + ITF[1].num);
		System.out.println("向西");
		System.out.println(ITF[2].state + ":" + ITF[2].id + "," + ITF[2].num);
		System.out.println("向北");
		System.out.println(ITF[3].state + ":" + ITF[3].id + "," + ITF[3].num);
		System.out.println("位于:" + on);
		System.out.println("仓库:" + iswarehouse);
		System.out.println("道路:" + isroad);
	}

	/**
	 * 刷新物流储存
	 */
	public void refresh() {
		if (iswarehouse != true) {
			System.err.println("Only ware house can refresh");
		}
		Date d = new Date();
		long interval = -(date.getTime() - d.getTime());
		int id = 0, num = 0;
		for (int[] item : temp) {
			if (id == 0)
				id = item[0];
			if (id == item[0])
				num += item[1];
		}
		if (id == 0)
			return;
		date = d;
		// System.out.println(interval);
		buff += (int) (num * interval);
		int n = buff / 1000;
		buff -= 1000 * n;
		// System.out.println("hh");
		Bag.add(id, n);
	}

	/**
	 * 切换贴图
	 * 
	 * @param id
	 * @return
	 */
	public int toWork(int id) {
		if (this.mode != WORK)
			return id;
		if (id == 401) {
			int sum = id;
			for (int i = 0; i < 4; i++) {
				if (this.ITF[i].state != 0) {
					sum += (1 << i);
				}
			}
			return sum;
		} else
			return id + 1;
	}

	public void refresh_image() {
		if (this.isroad == false)
			ReadMap.map2[y][x] = this.toWork(this.id);
		if (this.isroad == true)
			ReadMap.map1[y][x] = this.toWork(this.id);
	}

	/**
	 * 为了实现循环地图
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public static int Mod(int x, int y) {
		if (x < 0)
			return x + y;
		return x % y;
	}
}
