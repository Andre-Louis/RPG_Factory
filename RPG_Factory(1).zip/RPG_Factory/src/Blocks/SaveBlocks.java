package Blocks;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import GameWindow.StartPanel;

/**
 * 储存BLOCK信息到XML文件
 * 
 * @author gongzhili
 *
 */
public class SaveBlocks {
	/**
	 * 储存函数
	 */
	public static void Save() {
		try {

			// 创建解析器工厂
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = factory.newDocumentBuilder();
			Document document = db.newDocument();
			// 不显示standalone="no"
			document.setXmlStandalone(true);
			Element blocks = document.createElement("blocks");
			int cnt = 0;
			for (Block[] b : Block.getMap()) {
				for (Block bb : b) {
					/* 如果没有这个建筑，就跳过 */
					if (bb == null || bb.getMode() == BlockConfig.TERM)
						continue;
					bb.Printinfo();
					Element block = document.createElement("block");
					block.setAttribute("id", "" + (cnt++));

					Element location = document.createElement("location");
					location.setTextContent(bb.x + "," + bb.y);
					block.appendChild(location);

					Element Time = document.createElement("Time");
					Time.setTextContent("Time:" + bb.date.getTime());
					block.appendChild(Time);

					Element id = document.createElement("id");
					id.setTextContent("id:" + bb.id);
					block.appendChild(id);

					Element mode = document.createElement("mode");
					mode.setTextContent("mode:" + bb.mode);
					block.appendChild(mode);

					Element Interface = document.createElement("Interface");
					Element East = document.createElement("East");
					East.setTextContent(bb.ITF[0].state + "," + bb.ITF[0].id + "," + bb.ITF[0].num);
					Interface.appendChild(East);
					Element South = document.createElement("South");
					South.setTextContent(bb.ITF[1].state + "," + bb.ITF[1].id + "," + bb.ITF[1].num);
					Interface.appendChild(South);
					Element West = document.createElement("West");
					West.setTextContent(bb.ITF[2].state + "," + bb.ITF[2].id + "," + bb.ITF[2].num);
					Interface.appendChild(West);
					Element North = document.createElement("North");
					North.setTextContent(bb.ITF[3].state + "," + bb.ITF[3].id + "," + bb.ITF[3].num);
					Interface.appendChild(North);

					block.appendChild(Interface);

					blocks.appendChild(block);

				}
			}
			document.appendChild(blocks);
			// 创建TransformerFactory对象
			TransformerFactory tff = TransformerFactory.newInstance();
			// 创建 Transformer对象
			Transformer tf = tff.newTransformer();

			// 输出内容是否使用换行
			tf.setOutputProperty(OutputKeys.INDENT, "yes");
			// 创建xml文件并写入内容
			tf.transform(new DOMSource(document), new StreamResult(new File(StartPanel.path + StartPanel.name +"/blocks.xml")));
			System.out.println("生成成功");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("生成失败");
		}

	}
}
