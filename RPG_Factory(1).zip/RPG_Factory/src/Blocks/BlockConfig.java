package Blocks;

/**
 * 
 * @author andrexu
 *
 */

public interface BlockConfig {
	/* Block模式 */
    int REST = 0;
    int WORK = 1;
    int TERM = 2; //虚无状态
    
}
