package Blocks;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.io.File;
import javax.xml.parsers.*;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import GameWindow.GameConfig;
import GameWindow.StartPanel;
import Maps.ReadMap;

/**
 * 
 * @author gzl, andrexu
 *
 */

public class RestoreBlocks {
	public static Set<Integer> tree= new HashSet<Integer>();
	public static Set<Integer> land= new HashSet<Integer>();
	
	public static void ReadXML() {
		try {
			tree.add(201);
			land.add(401);
			land.add(501);
			land.add(203);
			land.add(205);
			
			File f = new File(StartPanel.path + StartPanel.name + "/blocks.xml");
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    Document doc = builder.parse(f);
		  //获取xml中的节点
		    NodeList nl = doc.getElementsByTagName("block");
		    for (int i = 0; i < nl.getLength(); ++i) {
		    	String location = doc.getElementsByTagName("location").item(i).getTextContent();
		    	String Time = doc.getElementsByTagName("Time").item(i).getTextContent();
		    	String id = doc.getElementsByTagName("id").item(i).getTextContent();
		    	String mode = doc.getElementsByTagName("mode").item(i).getTextContent();
		    	String[] East = doc.getElementsByTagName("East").item(i).getTextContent().split(",");
		    	String[] South = doc.getElementsByTagName("South").item(i).getTextContent().split(",");
		    	String[] West = doc.getElementsByTagName("West").item(i).getTextContent().split(",");
		    	String[] North = doc.getElementsByTagName("North").item(i).getTextContent().split(",");
		    	
		    	
		    	
				Block b = new Block();
				b.input = new int[4][2];
		    	b.output = new int[4][2];
		    	b.temp = new int[4][2];
		    	b.level=1;
		    	
				// restore id
		        b.id = Integer.valueOf(id.substring(3));
		    	// restore location
		        int x = Integer.valueOf(location.split(",")[0]);
		        int y = Integer.valueOf(location.split(",")[1]);
		        Block.map[x][y] = b;
		        int[][] d= {{Block.Mod(b.x+1,GameConfig.MapWidth/GameConfig.elesize),y},{x,
		        	Block.Mod(y+1,GameConfig.MapHeight/GameConfig.elesize)},{Block.Mod(x-1,GameConfig.MapWidth/GameConfig.elesize),y},{x,Block.Mod(y-1,GameConfig.MapHeight/GameConfig.elesize)}};
		    	b.directions=d;

		        b.x=x;
		        b.y=y;
		       //restore information
		    	String[][] info=BlockOperator.map.get(b.id);
				//在树上
				if(tree.contains(b.id))
				{
					b.on=10;
				}
				//在地上
				if(land.contains(b.id))
				{
					b.on=5;
				}
				for(int k=0;k<2;k++)
				{
					int cnt=0;
					int index=0;
					while(info[k][cnt]!="0")
					{
						System.out.println(k+","+info[k][cnt]+","+info[k][cnt+1]);
						//如果是物流类则退出
						if(info[k][cnt].equals("x"))
						{
							b.isroad=true;
							break;
						}
						int id_=Integer.parseInt(info[k][cnt]);
						int num_=Integer.parseInt(info[k][cnt+1]);
						if(k==0)
						{
							b.input[index][0]=id_;
							b.input[index][1]=num_;
							index++;
						}
						else if(k==1)
						{
							b.output[index][0]=id_;
							b.output[index][1]=num_;
							index++;
						}
						cnt+=2;
						if(cnt>=info[k].length)break;
					}
				}
				b.costid=Integer.parseInt(info[2][0]);
				b.costnum=Integer.parseInt(info[2][1]);
				if(b.isroad)
				{
					if(b.id==501)b.iswarehouse=true;
					b.level=1;
					ReadMap.map1[y][x]=b.id;
				}
				else
				{
					b.level=2;
					ReadMap.map2[y][x]=b.id;
				}
				
				//b.Printinfo();

		        
		        // restore time
		        b.date = new Date(Long.parseLong(Time.substring(5)));
		        
		        
		        // restore mode
		        b.mode = Integer.valueOf(mode.substring(5));
		        
		        // restore Interface
		        b.ITF[0].state = Integer.valueOf(East[0]);
		        b.ITF[0].id = Integer.valueOf(East[1]);
		        b.ITF[0].num = Integer.valueOf(East[2]);
		        b.ITF[1].state = Integer.valueOf(South[0]);
		        b.ITF[1].id = Integer.valueOf(South[1]);
		        b.ITF[1].num = Integer.valueOf(South[2]);
		        b.ITF[2].state = Integer.valueOf(West[0]);
		        b.ITF[2].id = Integer.valueOf(West[1]);
		        b.ITF[2].num = Integer.valueOf(West[2]);
		        b.ITF[3].state = Integer.valueOf(North[0]);
		        b.ITF[3].id = Integer.valueOf(North[1]);
		        b.ITF[3].num = Integer.valueOf(North[2]);
		        
		        if(b.mode==Block.WORK)
		        {
		        	if(b.isroad) {
		        		//增加输入
		        		int id_=0;
		        		int num_=0;
		        		for(int j=0;j<4;j++)
			        	{
			        		if(b.ITF[j].state==1)
			        		{
			        			if(id_==0)
			        			{
			        				id_=b.ITF[j].id;
			        			}
						    	if(id_==b.ITF[j].id)
						    	{
						    		num_+=b.ITF[j].num;
						    	}
			        		}
			        	}
		        		if(id_!=0)
		        		{
		        			b.temp[0][0]=id_;
		        			b.temp[0][1]=num_;
		        		}
		        		for(int j=0;j<4;j++)
			        	{
			        		if(b.ITF[j].state==2)
			        		{
			        			for(int k=0;k<4;k++)
						    	{
						    		if(b.temp[k][0]==b.ITF[j].id)
						    		{
						    			b.temp[k][1]-=b.ITF[j].num;
						    			if(b.temp[k][1]==0)
						    			{
						    				b.temp[k][0]=0;
						    			}
						    		}
						    	}
			        		}
			        	}
		        	}
		        	else {
			        	//把输出规划到盈余产出
				    	for(int k=0;k<4;k++)
				    	{
				    		if(b.output[k][0]!=101)
				    		{
					    		b.temp[k][0]=b.output[k][0];
					    		b.temp[k][1]=b.output[k][1];
				    		}
				    	}
				    	
	
			        	for(int j=0;j<4;j++)
			        	{
			        		if(b.ITF[j].state==2)
			        		{
			        			for(int k=0;k<4;k++)
						    	{
						    		if(b.temp[k][0]==b.ITF[j].id)
						    		{
						    			b.temp[k][1]-=b.ITF[j].num;
						    			if(b.temp[k][1]==0)
						    			{
						    				b.temp[k][0]=0;
						    			}
						    		}
						    	}
			        		}
			        	}
		        	}
		        	b.refresh_image();
		        }
		        
		        b.Printinfo();
		    }
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
