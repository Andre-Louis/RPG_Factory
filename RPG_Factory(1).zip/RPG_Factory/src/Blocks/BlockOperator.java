package Blocks;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.concurrent.ConcurrentHashMap;

import GameWindow.OperatePanel;
import Maps.ReadMap;

/**
 * 对方块操作函数的封装
 * 
 * @author gongzhili
 *
 */
public class BlockOperator {
	/* id 信息的map */
	public static ConcurrentHashMap<Integer, String[][]> map = new ConcurrentHashMap<Integer, String[][]>();

	/**
	 * 初始化map
	 */
	public static void init() {
		try {
			/* 读取tree.csv文件 */
			BufferedReader reader = new BufferedReader(new FileReader("material/OperatorBox/tree.csv"));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String item[] = line.split(",");// CSV格式文件为逗号分隔符文件，这里根据逗号切分
				int id = Integer.parseInt(item[0]);
				String line1[] = reader.readLine().split(",");
				String line2[] = reader.readLine().split(",");
				int length = Math.max(line1.length, line2.length);
				String[][] info = new String[3][length];
				info[0] = line1;
				info[1] = line2;
				info[2][0] = item[1];
				info[2][1] = item[2];
				map.put(id, info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * String转换int的建造函数
	 * 
	 * @param x
	 * @param y
	 * @param name
	 */
	public static void Build(int x, int y, String name) {
		int id = name2id(name);
		Build(x, y, id);
	}

	/**
	 * 建造函数的封装
	 * 
	 * @param x
	 * @param y
	 * @param id
	 */
	public static void Build(int x, int y, int id) {
		if (Block.map[x][y] != null && Block.map[x][y].mode != Block.TERM) {
			System.err.println("Already built another building here");// 如果此处已经有建筑了
			OperatePanel.error_msg("Already built another building here");
			return;
		}
		if (id == 0) {
			System.err.println("Trying to Create a block with unknown name");// 如果试图建造的id没有在列表当中
			OperatePanel.error_msg("Trying to Create a block with unknown name");
			return;
		}

		System.out.println("Creating " + id + "---------------");
		/* 获取对应信息 */
		String[][] info = map.get(id);

		Block b = new Block();
		/* 建造需求 */
		b.costid = Integer.parseInt(info[2][0]);
		b.costnum = Integer.parseInt(info[2][1]);

		/* 在树上 */
		if (RestoreBlocks.tree.contains(id))// ||
		{
			if (OperatePanel.status != OperatePanel.IS_TREE) {
				System.err.println("Can't build a LumberYard on land");
				OperatePanel.error_msg("Can't build a LumberYard on land");
				return;
			}
			b.on = 10;
		}
		/* 在地上 */
		if (RestoreBlocks.land.contains(id)) {
			if (OperatePanel.status != OperatePanel.IS_AVAILABLE) {
				System.err.println("Can't build a Road without land");
				OperatePanel.error_msg("Can't build a Road without land");
				return;
			}
			b.on = 5;
		}
		/* 尝试扣除资源 */
		boolean d = Bag.del(b.costid, b.costnum);
		if (d == false) {
			System.err.println("Raw material shortage！");
			return;
		}
		/* 初始化 */
		b.init(x, y);
		b.id = id;
		/* 设置input、output */
		for (int i = 0; i < 2; i++) {
			int cnt = 0;
			int index = 0;
			while (info[i][cnt] != "0") {
				// 如果是物流类则退出
				if (info[i][cnt].equals("x")) {
					b.isroad = true;
					break;
				}
				int id_ = Integer.parseInt(info[i][cnt]);
				int num_ = Integer.parseInt(info[i][cnt + 1]);
				if (i == 0) {
					b.input[index][0] = id_;
					b.input[index][1] = num_;
					index++;
				} else if (i == 1) {
					b.output[index][0] = id_;
					b.output[index][1] = num_;
					index++;
				}
				cnt += 2;
				if (cnt >= info[i].length)
					break;
			}
		}
		/* 设置level并更改贴图 */
		if (b.isroad) {
			if (id == 501)
				b.iswarehouse = true;
			b.level = 1;
			ReadMap.map1[y][x] = id;
		} else {
			b.level = 2;
			ReadMap.map2[y][x] = id;
		}

		b.Printinfo();
	}

	/**
	 * 删除函数封装
	 * 
	 * @param x
	 * @param y
	 */
	public static void Delete(int x, int y) {
		/* 获取带删除BLOCK */
		Block block = Block.getMap()[x][y];
		/* 如果不存在删除建筑 */
		if (block == null) {
			System.err.println("There isn't any buildings");
			OperatePanel.error_msg("There isn't any buildings");
			return;
		}

		/* 尝试删除 */
		boolean b = block.delete();
		if (!b) {
			System.err.println("Can't delete a building when it is working!");
			OperatePanel.error_msg("Can't delete a building when it is working!");
			return;
		}
		/* 恢复原有贴图 */
		if (block.level == 1) {
			ReadMap.map1[y][x] = block.on;
		} else
			ReadMap.map2[y][x] = block.on;
	}

	/**
	 * 激活函数封装
	 * 
	 * @param x
	 * @param y
	 */
	public static void Start(int x, int y) {
		/* 获取待激活函数 */
		Block block = Block.getMap()[x][y];
		boolean b = block.Start();
		if (!b) {
			System.err.println("Can't start the building");
			OperatePanel.error_msg("Can't start the building");
			return;
		}
		/* 刷新贴图 */
		block.refresh_image();
		block.Printinfo();
	}

	/**
	 * 暂停函数的封装
	 * 
	 * @param x
	 * @param y
	 */
	public static void Pause(int x, int y) {
		/* 获取待暂停函数 */
		Block block = Block.getMap()[x][y];
		boolean b = block.pause();
		if (!b) {
			System.err.println("Can't pause the building");
			OperatePanel.error_msg("Can't pause the building");
			return;
		}
		/* 刷新贴图 */
		block.refresh_image();
		block.Printinfo();
	}

	/**
	 * 将String转化为对应的id，如果无法转换返回0
	 * 
	 * @param name
	 * @return
	 */
	public static int name2id(String name) {
		switch (name) {
		case "伐木场":
			return 201;
		case "道路":
			return 401;
		case "仓库":
			return 501;
		case "农田":
			return 203;
		case "茅草房":
			return 205;
		}
		return 0;
	}

}
